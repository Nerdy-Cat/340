from pymongo import MongoClient

class CRUD:
    def __init__(self, db_name, collection_name, username, password):
        self.client = MongoClient(f'mongodb://{username}:{password}@localhost:27017/{db_name}')
        self.db = self.client[db_name]
        self.collection = self.db[collection_name]

    def create(self, data):
        try:
            result = self.collection.insert_one(data)
            return True
        except Exception as e:
            print(f"Error inserting document: {e}")
            return False

    def read(self, query):
        try:
            results = list(self.collection.find(query))
            return results
        except Exception as e:
            print(f"Error reading documents: {e}")
            return []

    def update(self, query, updates):
        try:
            result = self.collection.update_many(query, {'$set': updates})
            return result.modified_count
        except Exception as e:
            print(f"Error updating documents: {e}")
            return 0

    def delete(self, query):
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"Error deleting documents: {e}")
            return 0
